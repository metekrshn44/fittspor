import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Dumbbell, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const { isAuthenticated, logout, user } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-blue-600 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center" onClick={closeMenu}>
              <Dumbbell className="h-8 w-8 mr-2" />
              <span className="font-bold text-xl">FitTrack</span>
            </Link>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/" className="hover:bg-blue-700 px-3 py-2 rounded-md">Home</Link>
            
            {isAuthenticated ? (
              <>
                <Link to="/welcome" className="hover:bg-blue-700 px-3 py-2 rounded-md">Dashboard</Link>
                <Link to="/routines" className="hover:bg-blue-700 px-3 py-2 rounded-md">Routines</Link>
                <Link to="/nutrition" className="hover:bg-blue-700 px-3 py-2 rounded-md">Nutrition</Link>
                <Link to="/training" className="hover:bg-blue-700 px-3 py-2 rounded-md">Training</Link>
                <Link to="/timer" className="hover:bg-blue-700 px-3 py-2 rounded-md">Timer</Link>
                <Link to="/contact" className="hover:bg-blue-700 px-3 py-2 rounded-md">Contact</Link>
                <div className="px-3 py-2">Hi, {user?.username}</div>
                <button 
                  onClick={handleLogout}
                  className="bg-orange-500 hover:bg-orange-600 px-4 py-2 rounded-md transition duration-300 ease-in-out"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/contact" className="hover:bg-blue-700 px-3 py-2 rounded-md">Contact</Link>
                <Link 
                  to="/login" 
                  className="bg-orange-500 hover:bg-orange-600 px-4 py-2 rounded-md transition duration-300 ease-in-out"
                >
                  Login
                </Link>
                <Link 
                  to="/register" 
                  className="bg-blue-800 hover:bg-blue-900 px-4 py-2 rounded-md transition duration-300 ease-in-out"
                >
                  Register
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button onClick={toggleMenu} className="text-white focus:outline-none">
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-blue-600 pb-3 px-4">
          <Link to="/" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Home</Link>
          
          {isAuthenticated ? (
            <>
              <Link to="/welcome" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Dashboard</Link>
              <Link to="/routines" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Routines</Link>
              <Link to="/nutrition" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Nutrition</Link>
              <Link to="/training" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Training</Link>
              <Link to="/timer" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Timer</Link>
              <Link to="/contact" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Contact</Link>
              <div className="px-3 py-2 text-white">Hi, {user?.username}</div>
              <button 
                onClick={() => { handleLogout(); closeMenu(); }}
                className="block w-full text-left px-3 py-2 bg-orange-500 hover:bg-orange-600 rounded-md mt-2 transition duration-300 ease-in-out"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/contact" className="block px-3 py-2 hover:bg-blue-700 rounded-md" onClick={closeMenu}>Contact</Link>
              <Link 
                to="/login" 
                className="block w-full text-left px-3 py-2 bg-orange-500 hover:bg-orange-600 rounded-md mt-2 transition duration-300 ease-in-out"
                onClick={closeMenu}
              >
                Login
              </Link>
              <Link 
                to="/register" 
                className="block w-full text-left px-3 py-2 bg-blue-800 hover:bg-blue-900 rounded-md mt-2 transition duration-300 ease-in-out"
                onClick={closeMenu}
              >
                Register
              </Link>
            </>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;