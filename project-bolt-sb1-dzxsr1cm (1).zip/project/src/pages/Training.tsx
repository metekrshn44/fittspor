import React, { useState } from 'react';
import Layout from '../components/Layout';
import { Calendar, Plus, Edit3, Trash2, CheckCircle, X, Dumbbell, ArrowRight } from 'lucide-react';

interface Exercise {
  id: number;
  name: string;
  sets: number;
  reps: string;
  weight: string;
  notes: string;
}

interface Workout {
  id: number;
  title: string;
  date: string;
  completed: boolean;
  duration: number;
  exercises: Exercise[];
}

const initialWorkouts: Workout[] = [
  {
    id: 1,
    title: 'Upper Body Strength',
    date: '2025-05-15',
    completed: true,
    duration: 60,
    exercises: [
      { id: 1, name: 'Bench Press', sets: 4, reps: '8-10', weight: '80kg', notes: 'Increase weight next time' },
      { id: 2, name: 'Pull-ups', sets: 3, reps: '10', weight: 'Bodyweight', notes: 'Focus on form' },
      { id: 3, name: 'Shoulder Press', sets: 3, reps: '12', weight: '20kg', notes: '' },
    ]
  },
  {
    id: 2,
    title: 'Leg Day',
    date: '2025-05-17',
    completed: false,
    duration: 75,
    exercises: [
      { id: 1, name: 'Squats', sets: 5, reps: '5', weight: '100kg', notes: 'Focus on depth' },
      { id: 2, name: 'Deadlift', sets: 3, reps: '8', weight: '120kg', notes: 'Keep back straight' },
      { id: 3, name: 'Leg Press', sets: 4, reps: '12', weight: '150kg', notes: '' },
      { id: 4, name: 'Calf Raises', sets: 3, reps: '15', weight: '40kg', notes: 'Squeeze at top' },
    ]
  },
  {
    id: 3,
    title: 'HIIT Cardio',
    date: '2025-05-19',
    completed: false,
    duration: 30,
    exercises: [
      { id: 1, name: 'Burpees', sets: 3, reps: '20', weight: 'Bodyweight', notes: '30 sec rest between sets' },
      { id: 2, name: 'Mountain Climbers', sets: 3, reps: '30 sec', weight: 'Bodyweight', notes: '' },
      { id: 3, name: 'Jump Squats', sets: 3, reps: '15', weight: 'Bodyweight', notes: 'Explosive movement' },
    ]
  }
];

const Training: React.FC = () => {
  const [workouts, setWorkouts] = useState<Workout[]>(initialWorkouts);
  const [showWorkoutForm, setShowWorkoutForm] = useState(false);
  const [showExerciseForm, setShowExerciseForm] = useState(false);
  const [currentWorkout, setCurrentWorkout] = useState<Workout | null>(null);
  const [currentExercise, setCurrentExercise] = useState<Exercise | null>(null);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'history'>('upcoming');
  
  const [newWorkout, setNewWorkout] = useState({
    title: '',
    date: new Date().toISOString().split('T')[0],
    duration: 60
  });
  
  const [newExercise, setNewExercise] = useState({
    name: '',
    sets: 3,
    reps: '',
    weight: '',
    notes: ''
  });

  const handleAddWorkout = () => {
    setCurrentWorkout(null);
    setNewWorkout({
      title: '',
      date: new Date().toISOString().split('T')[0],
      duration: 60
    });
    setShowWorkoutForm(true);
  };

  const handleEditWorkout = (workout: Workout) => {
    setCurrentWorkout(workout);
    setNewWorkout({
      title: workout.title,
      date: workout.date,
      duration: workout.duration
    });
    setShowWorkoutForm(true);
  };

  const handleWorkoutFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewWorkout({
      ...newWorkout,
      [name]: name === 'duration' ? parseInt(value) : value
    });
  };

  const handleWorkoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (currentWorkout) {
      // Update existing workout
      setWorkouts(workouts.map(w => 
        w.id === currentWorkout.id 
          ? { 
              ...currentWorkout, 
              title: newWorkout.title, 
              date: newWorkout.date, 
              duration: newWorkout.duration 
            } 
          : w
      ));
    } else {
      // Create new workout
      const newId = Math.max(0, ...workouts.map(w => w.id)) + 1;
      const workout: Workout = {
        id: newId,
        title: newWorkout.title,
        date: newWorkout.date,
        completed: false,
        duration: newWorkout.duration,
        exercises: []
      };
      setWorkouts([...workouts, workout]);
    }
    
    setShowWorkoutForm(false);
  };

  const handleAddExercise = (workout: Workout) => {
    setCurrentWorkout(workout);
    setCurrentExercise(null);
    setNewExercise({
      name: '',
      sets: 3,
      reps: '',
      weight: '',
      notes: ''
    });
    setShowExerciseForm(true);
  };

  const handleEditExercise = (workout: Workout, exercise: Exercise) => {
    setCurrentWorkout(workout);
    setCurrentExercise(exercise);
    setNewExercise({
      name: exercise.name,
      sets: exercise.sets,
      reps: exercise.reps,
      weight: exercise.weight,
      notes: exercise.notes
    });
    setShowExerciseForm(true);
  };

  const handleExerciseFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewExercise({
      ...newExercise,
      [name]: name === 'sets' ? parseInt(value) : value
    });
  };

  const handleExerciseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentWorkout) return;
    
    if (currentExercise) {
      // Update existing exercise
      const updatedWorkouts = workouts.map(workout => {
        if (workout.id === currentWorkout.id) {
          const updatedExercises = workout.exercises.map(exercise => 
            exercise.id === currentExercise.id 
              ? { 
                  ...exercise,
                  name: newExercise.name,
                  sets: newExercise.sets,
                  reps: newExercise.reps,
                  weight: newExercise.weight,
                  notes: newExercise.notes
                }
              : exercise
          );
          return { ...workout, exercises: updatedExercises };
        }
        return workout;
      });
      setWorkouts(updatedWorkouts);
    } else {
      // Add new exercise
      const newId = Math.max(0, ...currentWorkout.exercises.map(e => e.id), 0) + 1;
      const exercise: Exercise = {
        id: newId,
        name: newExercise.name,
        sets: newExercise.sets,
        reps: newExercise.reps,
        weight: newExercise.weight,
        notes: newExercise.notes
      };
      
      const updatedWorkouts = workouts.map(workout => 
        workout.id === currentWorkout.id 
          ? { ...workout, exercises: [...workout.exercises, exercise] }
          : workout
      );
      setWorkouts(updatedWorkouts);
    }
    
    setShowExerciseForm(false);
  };

  const handleDeleteWorkout = (id: number) => {
    setWorkouts(workouts.filter(workout => workout.id !== id));
  };

  const handleDeleteExercise = (workoutId: number, exerciseId: number) => {
    const updatedWorkouts = workouts.map(workout => {
      if (workout.id === workoutId) {
        return {
          ...workout,
          exercises: workout.exercises.filter(exercise => exercise.id !== exerciseId)
        };
      }
      return workout;
    });
    setWorkouts(updatedWorkouts);
  };

  const toggleWorkoutCompletion = (id: number) => {
    setWorkouts(workouts.map(workout => 
      workout.id === id ? { ...workout, completed: !workout.completed } : workout
    ));
  };

  // Filter workouts based on tab
  const upcomingWorkouts = workouts
    .filter(workout => !workout.completed)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
  const workoutHistory = workouts
    .filter(workout => workout.completed)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <Layout>
      <div className="bg-blue-50 py-8 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Training Plan</h1>
              <p className="text-lg text-gray-600 mt-2">
                Plan, track, and optimize your workout sessions
              </p>
            </div>
            
            <button
              onClick={handleAddWorkout}
              className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Plus className="-ml-1 mr-2 h-5 w-5" />
              Add Workout
            </button>
          </div>

          {/* Workout form */}
          {showWorkoutForm && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-blue-500">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                  {currentWorkout ? 'Edit Workout' : 'Create New Workout'}
                </h2>
                <button 
                  onClick={() => setShowWorkoutForm(false)} 
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <form onSubmit={handleWorkoutSubmit}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                      Workout Title *
                    </label>
                    <input
                      type="text"
                      name="title"
                      id="title"
                      required
                      value={newWorkout.title}
                      onChange={handleWorkoutFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="e.g., Upper Body Strength"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                      Date *
                    </label>
                    <input
                      type="date"
                      name="date"
                      id="date"
                      required
                      value={newWorkout.date}
                      onChange={handleWorkoutFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="duration" className="block text-sm font-medium text-gray-700">
                      Duration (minutes) *
                    </label>
                    <input
                      type="number"
                      name="duration"
                      id="duration"
                      required
                      min="5"
                      value={newWorkout.duration}
                      onChange={handleWorkoutFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowWorkoutForm(false)}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {currentWorkout ? 'Update Workout' : 'Create Workout'}
                  </button>
                </div>
              </form>
            </div>
          )}
          
          {/* Exercise form */}
          {showExerciseForm && currentWorkout && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-green-500">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                  {currentExercise ? 'Edit Exercise' : 'Add Exercise to'} <span className="text-blue-600">{currentWorkout.title}</span>
                </h2>
                <button 
                  onClick={() => setShowExerciseForm(false)} 
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <form onSubmit={handleExerciseSubmit}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Exercise Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      required
                      value={newExercise.name}
                      onChange={handleExerciseFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="e.g., Bench Press"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="sets" className="block text-sm font-medium text-gray-700">
                      Sets *
                    </label>
                    <input
                      type="number"
                      name="sets"
                      id="sets"
                      required
                      min="1"
                      value={newExercise.sets}
                      onChange={handleExerciseFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="reps" className="block text-sm font-medium text-gray-700">
                      Reps *
                    </label>
                    <input
                      type="text"
                      name="reps"
                      id="reps"
                      required
                      value={newExercise.reps}
                      onChange={handleExerciseFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="e.g., 8-10 or 30 sec"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="weight" className="block text-sm font-medium text-gray-700">
                      Weight
                    </label>
                    <input
                      type="text"
                      name="weight"
                      id="weight"
                      value={newExercise.weight}
                      onChange={handleExerciseFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="e.g., 60kg or Bodyweight"
                    />
                  </div>
                  
                  <div className="sm:col-span-2">
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                      Notes
                    </label>
                    <textarea
                      name="notes"
                      id="notes"
                      rows={3}
                      value={newExercise.notes}
                      onChange={handleExerciseFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="Any special instructions or reminders"
                    ></textarea>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowExerciseForm(false)}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {currentExercise ? 'Update Exercise' : 'Add Exercise'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Workout Tabs */}
          <div className="bg-white rounded-t-lg shadow-sm">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex" aria-label="Tabs">
                <button
                  onClick={() => setActiveTab('upcoming')}
                  className={`w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm ${
                    activeTab === 'upcoming'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Upcoming Workouts
                </button>
                <button
                  onClick={() => setActiveTab('history')}
                  className={`w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm ${
                    activeTab === 'history'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Workout History
                </button>
              </nav>
            </div>
          </div>

          {/* Workouts List */}
          <div className="bg-white rounded-b-lg shadow-md overflow-hidden mb-8">
            {activeTab === 'upcoming' ? (
              upcomingWorkouts.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <Dumbbell className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-lg font-medium text-gray-900">No upcoming workouts</h3>
                  <p className="mt-1 text-sm text-gray-500">Get started by creating your first workout.</p>
                  <div className="mt-6">
                    <button
                      onClick={handleAddWorkout}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <Plus className="-ml-1 mr-2 h-5 w-5" />
                      Add Workout
                    </button>
                  </div>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {upcomingWorkouts.map((workout) => (
                    <div key={workout.id} className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">{workout.title}</h3>
                            <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {workout.duration} min
                            </span>
                          </div>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                            <span>{formatDate(workout.date)}</span>
                          </div>
                        </div>
                        <div className="flex mt-4 md:mt-0 space-x-2">
                          <button
                            onClick={() => toggleWorkoutCompletion(workout.id)}
                            className="p-1 rounded-full text-green-600 hover:text-green-700 bg-green-100 hover:bg-green-200"
                            title="Mark as completed"
                          >
                            <CheckCircle className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleEditWorkout(workout)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                            title="Edit workout"
                          >
                            <Edit3 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteWorkout(workout.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                            title="Delete workout"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                      
                      {/* Exercises */}
                      <div className="mt-4">
                        <div className="flex justify-between items-center mb-3">
                          <h4 className="text-sm font-medium text-gray-700">Exercises</h4>
                          <button
                            onClick={() => handleAddExercise(workout)}
                            className="inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Add Exercise
                          </button>
                        </div>
                        
                        {workout.exercises.length === 0 ? (
                          <p className="text-sm text-gray-500 italic">No exercises added yet. Add your first exercise to get started.</p>
                        ) : (
                          <div className="overflow-hidden border border-gray-200 rounded-md">
                            <table className="min-w-full divide-y divide-gray-200">
                              <thead className="bg-gray-50">
                                <tr>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Exercise
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Sets
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Reps
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Weight
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Notes
                                  </th>
                                  <th scope="col" className="relative px-4 py-3">
                                    <span className="sr-only">Actions</span>
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-200">
                                {workout.exercises.map((exercise) => (
                                  <tr key={exercise.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                      {exercise.name}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.sets}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.reps}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.weight}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.notes}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                                      <div className="flex space-x-1 justify-end">
                                        <button
                                          onClick={() => handleEditExercise(workout, exercise)}
                                          className="text-blue-600 hover:text-blue-900"
                                        >
                                          <Edit3 className="h-4 w-4" />
                                        </button>
                                        <button
                                          onClick={() => handleDeleteExercise(workout.id, exercise.id)}
                                          className="text-red-600 hover:text-red-900"
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )
            ) : (
              // Workout History
              workoutHistory.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <CheckCircle className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-lg font-medium text-gray-900">No completed workouts</h3>
                  <p className="mt-1 text-sm text-gray-500">Complete a workout to see it in your history.</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {workoutHistory.map((workout) => (
                    <div key={workout.id} className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">{workout.title}</h3>
                            <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Completed
                            </span>
                            <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {workout.duration} min
                            </span>
                          </div>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                            <span>{formatDate(workout.date)}</span>
                          </div>
                        </div>
                        <div className="flex mt-4 md:mt-0 space-x-2">
                          <button
                            onClick={() => toggleWorkoutCompletion(workout.id)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                            title="Mark as incomplete"
                          >
                            <ArrowRight className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteWorkout(workout.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                            title="Delete from history"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                      
                      {/* Exercises */}
                      {workout.exercises.length > 0 && (
                        <div className="mt-4">
                          <h4 className="text-sm font-medium text-gray-700 mb-3">Completed Exercises</h4>
                          <div className="overflow-hidden border border-gray-200 rounded-md">
                            <table className="min-w-full divide-y divide-gray-200">
                              <thead className="bg-gray-50">
                                <tr>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Exercise
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Sets
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Reps
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Weight
                                  </th>
                                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Notes
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-200">
                                {workout.exercises.map((exercise) => (
                                  <tr key={exercise.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                      {exercise.name}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.sets}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.reps}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.weight}
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {exercise.notes}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )
            )}
          </div>
          
          {/* Tips Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-orange-500">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Training Tips</h3>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>Vary your workout intensity and include both strength and cardio exercises</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>Focus on proper form rather than lifting heavier weights</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>Allow 48 hours of recovery time for muscle groups between workouts</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>Track your progress over time to stay motivated and see improvements</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Training;