import React, { useState, useEffect, useRef } from 'react';
import Layout from '../components/Layout';
import { Play, Pause, RotateCcw, Settings, Plus, Minus, Save, Trash2, Edit3, Clock, X } from 'lucide-react';

interface TimerPreset {
  id: number;
  name: string;
  workTime: number;
  restTime: number;
  rounds: number;
}

const initialPresets: TimerPreset[] = [
  { id: 1, name: 'HIIT', workTime: 30, restTime: 15, rounds: 8 },
  { id: 2, name: 'Tabata', workTime: 20, restTime: 10, rounds: 8 },
  { id: 3, name: 'Strength', workTime: 60, restTime: 90, rounds: 5 },
];

const Timer: React.FC = () => {
  // Timer logic
  const [workTime, setWorkTime] = useState(30);
  const [restTime, setRestTime] = useState(15);
  const [rounds, setRounds] = useState(8);
  const [currentRound, setCurrentRound] = useState(1);
  const [isWorking, setIsWorking] = useState(true);
  const [timeLeft, setTimeLeft] = useState(workTime);
  const [isActive, setIsActive] = useState(false);
  const [presets, setPresets] = useState<TimerPreset[]>(initialPresets);
  
  // Preset form state
  const [showPresetForm, setShowPresetForm] = useState(false);
  const [currentPreset, setCurrentPreset] = useState<TimerPreset | null>(null);
  const [newPreset, setNewPreset] = useState({
    name: '',
    workTime: 30,
    restTime: 15,
    rounds: 8
  });
  
  // Sound effects
  const startSound = useRef<HTMLAudioElement | null>(null);
  const endSound = useRef<HTMLAudioElement | null>(null);
  
  // Timer interval ref
  const interval = useRef<number | null>(null);

  // Setup and cleanup
  useEffect(() => {
    // Create audio elements
    startSound.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2530/2530.wav');
    endSound.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2529/2529.wav');
    
    return () => {
      if (interval.current) {
        clearInterval(interval.current);
      }
    };
  }, []);

  // Initialize timer when first loaded
  useEffect(() => {
    resetTimer();
  }, [workTime, restTime, rounds]);

  // Main timer logic
  useEffect(() => {
    if (isActive) {
      interval.current = window.setInterval(() => {
        if (timeLeft > 0) {
          setTimeLeft(timeLeft - 1);
        } else {
          // Play sound when transitioning
          if (isWorking) {
            endSound.current?.play();
          } else {
            startSound.current?.play();
          }
          
          if (isWorking) {
            // Transition to rest
            setIsWorking(false);
            setTimeLeft(restTime);
          } else {
            // Transition to next round or complete the workout
            if (currentRound < rounds) {
              setCurrentRound(currentRound + 1);
              setIsWorking(true);
              setTimeLeft(workTime);
            } else {
              // Workout complete
              completeWorkout();
            }
          }
        }
      }, 1000);
    } else if (!isActive && interval.current) {
      clearInterval(interval.current);
      interval.current = null;
    }
    
    return () => {
      if (interval.current) {
        clearInterval(interval.current);
      }
    };
  }, [isActive, timeLeft, isWorking, currentRound, rounds, workTime, restTime]);

  const startTimer = () => {
    if (isActive) return;
    
    if (currentRound === 1 && isWorking && timeLeft === workTime) {
      // Starting fresh
      startSound.current?.play();
    }
    
    setIsActive(true);
  };

  const pauseTimer = () => {
    setIsActive(false);
  };

  const resetTimer = () => {
    pauseTimer();
    setCurrentRound(1);
    setIsWorking(true);
    setTimeLeft(workTime);
  };

  const completeWorkout = () => {
    pauseTimer();
    setCurrentRound(1);
    setIsWorking(true);
    setTimeLeft(workTime);
    endSound.current?.play();
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const calculateProgress = (): number => {
    const totalSeconds = isWorking ? workTime : restTime;
    return ((totalSeconds - timeLeft) / totalSeconds) * 100;
  };

  // Preset management
  const handleAddPreset = () => {
    setCurrentPreset(null);
    setNewPreset({
      name: '',
      workTime: 30,
      restTime: 15,
      rounds: 8
    });
    setShowPresetForm(true);
  };

  const handleEditPreset = (preset: TimerPreset) => {
    setCurrentPreset(preset);
    setNewPreset({
      name: preset.name,
      workTime: preset.workTime,
      restTime: preset.restTime,
      rounds: preset.rounds
    });
    setShowPresetForm(true);
  };

  const handlePresetFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewPreset({
      ...newPreset,
      [name]: name === 'name' ? value : parseInt(value)
    });
  };

  const handlePresetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (currentPreset) {
      // Update existing preset
      setPresets(presets.map(preset => 
        preset.id === currentPreset.id 
          ? { 
              ...currentPreset, 
              name: newPreset.name,
              workTime: newPreset.workTime,
              restTime: newPreset.restTime,
              rounds: newPreset.rounds
            } 
          : preset
      ));
    } else {
      // Add new preset
      const newId = Math.max(0, ...presets.map(p => p.id)) + 1;
      const preset: TimerPreset = {
        id: newId,
        name: newPreset.name,
        workTime: newPreset.workTime,
        restTime: newPreset.restTime,
        rounds: newPreset.rounds
      };
      setPresets([...presets, preset]);
    }
    
    setShowPresetForm(false);
  };

  const handleDeletePreset = (id: number) => {
    setPresets(presets.filter(preset => preset.id !== id));
  };

  const applyPreset = (preset: TimerPreset) => {
    pauseTimer();
    setWorkTime(preset.workTime);
    setRestTime(preset.restTime);
    setRounds(preset.rounds);
    setCurrentRound(1);
    setIsWorking(true);
    setTimeLeft(preset.workTime);
  };

  const adjustValue = (setter: React.Dispatch<React.SetStateAction<number>>, value: number, amount: number, min: number) => {
    const newValue = Math.max(min, value + amount);
    setter(newValue);
    
    if (!isActive) {
      if (setter === setWorkTime && isWorking) {
        setTimeLeft(newValue);
      } else if (setter === setRestTime && !isWorking) {
        setTimeLeft(newValue);
      }
    }
  };

  return (
    <Layout>
      <div className="bg-blue-50 py-8 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Workout Timer</h1>
            <p className="text-lg text-gray-600 mt-2">
              Set your intervals, rest periods, and rounds for effective workouts
            </p>
          </div>

          {/* Timer Display */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <div className="relative">
              {/* Progress Bar */}
              <div 
                className={`h-2 ${isWorking ? 'bg-blue-600' : 'bg-red-500'}`} 
                style={{ width: `${calculateProgress()}%` }}
              ></div>
              
              {/* Timer Content */}
              <div className="p-8">
                <div className="flex flex-col items-center">
                  {/* Round and Phase Display */}
                  <div className="mb-4 flex items-center">
                    <span className="text-xl font-medium text-gray-700">Round {currentRound}/{rounds}</span>
                    <span className={`ml-4 inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      isWorking ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {isWorking ? 'WORK' : 'REST'}
                    </span>
                  </div>
                  
                  {/* Timer Display */}
                  <div className="mb-6">
                    <span className="text-7xl font-bold text-gray-900 font-mono">{formatTime(timeLeft)}</span>
                  </div>
                  
                  {/* Control Buttons */}
                  <div className="flex space-x-4">
                    {isActive ? (
                      <button
                        onClick={pauseTimer}
                        className="inline-flex items-center px-6 py-3 border border-transparent text-lg font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors duration-200"
                      >
                        <Pause className="mr-2 h-5 w-5" />
                        Pause
                      </button>
                    ) : (
                      <button
                        onClick={startTimer}
                        className="inline-flex items-center px-6 py-3 border border-transparent text-lg font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
                      >
                        <Play className="mr-2 h-5 w-5" />
                        Start
                      </button>
                    )}
                    
                    <button
                      onClick={resetTimer}
                      className="inline-flex items-center px-6 py-3 border border-gray-300 shadow-sm text-lg font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
                    >
                      <RotateCcw className="mr-2 h-5 w-5" />
                      Reset
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Timer Settings */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex items-center mb-6">
              <Settings className="h-6 w-6 text-gray-500 mr-2" />
              <h2 className="text-xl font-semibold">Timer Settings</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Work Time */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Work Time (sec)</h3>
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => adjustValue(setWorkTime, workTime, -5, 5)}
                    className="p-2 rounded-full bg-blue-200 text-blue-700 hover:bg-blue-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    disabled={isActive}
                  >
                    <Minus className="h-5 w-5" />
                  </button>
                  <span className="text-3xl font-bold text-gray-800">{workTime}</span>
                  <button
                    onClick={() => adjustValue(setWorkTime, workTime, 5, 5)}
                    className="p-2 rounded-full bg-blue-200 text-blue-700 hover:bg-blue-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    disabled={isActive}
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>
              </div>
              
              {/* Rest Time */}
              <div className="bg-red-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Rest Time (sec)</h3>
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => adjustValue(setRestTime, restTime, -5, 5)}
                    className="p-2 rounded-full bg-red-200 text-red-700 hover:bg-red-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                    disabled={isActive}
                  >
                    <Minus className="h-5 w-5" />
                  </button>
                  <span className="text-3xl font-bold text-gray-800">{restTime}</span>
                  <button
                    onClick={() => adjustValue(setRestTime, restTime, 5, 5)}
                    className="p-2 rounded-full bg-red-200 text-red-700 hover:bg-red-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                    disabled={isActive}
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>
              </div>
              
              {/* Rounds */}
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Rounds</h3>
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => adjustValue(setRounds, rounds, -1, 1)}
                    className="p-2 rounded-full bg-purple-200 text-purple-700 hover:bg-purple-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                    disabled={isActive}
                  >
                    <Minus className="h-5 w-5" />
                  </button>
                  <span className="text-3xl font-bold text-gray-800">{rounds}</span>
                  <button
                    onClick={() => adjustValue(setRounds, rounds, 1, 1)}
                    className="p-2 rounded-full bg-purple-200 text-purple-700 hover:bg-purple-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                    disabled={isActive}
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Presets Form */}
          {showPresetForm && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-blue-500">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                  {currentPreset ? 'Edit Preset' : 'Create New Preset'}
                </h2>
                <button 
                  onClick={() => setShowPresetForm(false)} 
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <form onSubmit={handlePresetSubmit}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Preset Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      required
                      value={newPreset.name}
                      onChange={handlePresetFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="e.g., HIIT Cardio"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="workTime" className="block text-sm font-medium text-gray-700">
                      Work Time (seconds) *
                    </label>
                    <input
                      type="number"
                      name="workTime"
                      id="workTime"
                      required
                      min="5"
                      value={newPreset.workTime}
                      onChange={handlePresetFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="restTime" className="block text-sm font-medium text-gray-700">
                      Rest Time (seconds) *
                    </label>
                    <input
                      type="number"
                      name="restTime"
                      id="restTime"
                      required
                      min="5"
                      value={newPreset.restTime}
                      onChange={handlePresetFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="rounds" className="block text-sm font-medium text-gray-700">
                      Rounds *
                    </label>
                    <input
                      type="number"
                      name="rounds"
                      id="rounds"
                      required
                      min="1"
                      value={newPreset.rounds}
                      onChange={handlePresetFormChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowPresetForm(false)}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {currentPreset ? 'Update Preset' : 'Save Preset'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Saved Presets */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <Clock className="h-6 w-6 text-gray-500 mr-2" />
                <h2 className="text-xl font-semibold">Saved Presets</h2>
              </div>
              <button
                onClick={handleAddPreset}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Plus className="-ml-1 mr-1 h-4 w-4" />
                New Preset
              </button>
            </div>
            
            {presets.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No presets saved</h3>
                <p className="mt-1 text-sm text-gray-500">Create your first preset to quickly load timer settings.</p>
                <div className="mt-6">
                  <button
                    onClick={handleAddPreset}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <Plus className="-ml-1 mr-2 h-5 w-5" />
                    Add Preset
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {presets.map((preset) => (
                  <div key={preset.id} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200">
                    <div className="bg-gray-50 px-4 py-2 border-b flex justify-between items-center">
                      <h3 className="font-medium text-gray-900">{preset.name}</h3>
                      <div className="flex space-x-1">
                        <button
                          onClick={() => handleEditPreset(preset)}
                          className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                          title="Edit preset"
                        >
                          <Edit3 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeletePreset(preset.id)}
                          className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                          title="Delete preset"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-3 gap-2 text-sm text-gray-600 mb-4">
                        <div>
                          <span className="block text-xs text-gray-500">Work</span>
                          <span className="font-medium text-gray-900">{preset.workTime}s</span>
                        </div>
                        <div>
                          <span className="block text-xs text-gray-500">Rest</span>
                          <span className="font-medium text-gray-900">{preset.restTime}s</span>
                        </div>
                        <div>
                          <span className="block text-xs text-gray-500">Rounds</span>
                          <span className="font-medium text-gray-900">{preset.rounds}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => applyPreset(preset)}
                        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        disabled={isActive}
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Timer;