import React, { useState } from 'react';
import Layout from '../components/Layout';
import { Plus, Edit3, Trash2, Check, X, Calendar, Repeat } from 'lucide-react';

interface Routine {
  id: number;
  name: string;
  description: string;
  frequency: string;
  completed: boolean;
}

const Routines: React.FC = () => {
  const [routines, setRoutines] = useState<Routine[]>([
    {
      id: 1,
      name: 'Morning Stretch',
      description: '15 minutes of full-body stretching to start the day',
      frequency: 'Daily',
      completed: false
    },
    {
      id: 2,
      name: 'Upper Body Workout',
      description: 'Focus on chest, back, shoulders and arms',
      frequency: 'Monday, Wednesday, Friday',
      completed: true
    },
    {
      id: 3,
      name: 'Lower Body Workout',
      description: 'Focus on legs, glutes and core',
      frequency: 'Tuesday, Thursday',
      completed: false
    },
    {
      id: 4,
      name: 'Cardio Session',
      description: '30 minutes of high-intensity cardio',
      frequency: 'Wednesday, Saturday',
      completed: true
    },
  ]);

  const [newRoutine, setNewRoutine] = useState<Omit<Routine, 'id' | 'completed'>>({
    name: '',
    description: '',
    frequency: ''
  });

  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<Routine | null>(null);

  const handleAddClick = () => {
    setIsAdding(true);
  };

  const handleCancelAdd = () => {
    setIsAdding(false);
    setNewRoutine({
      name: '',
      description: '',
      frequency: ''
    });
  };

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (newRoutine.name && newRoutine.frequency) {
      const newId = Math.max(0, ...routines.map(r => r.id)) + 1;
      setRoutines([...routines, { ...newRoutine, id: newId, completed: false }]);
      setNewRoutine({
        name: '',
        description: '',
        frequency: ''
      });
      setIsAdding(false);
    }
  };

  const handleNewRoutineChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewRoutine({
      ...newRoutine,
      [name]: value
    });
  };

  const handleEditClick = (routine: Routine) => {
    setEditingId(routine.id);
    setEditFormData({ ...routine });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditFormData(null);
  };

  const handleEditFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (editFormData) {
      const { name, value } = e.target;
      setEditFormData({
        ...editFormData,
        [name]: value
      });
    }
  };

  const handleUpdateRoutine = (e: React.FormEvent) => {
    e.preventDefault();
    if (editFormData) {
      setRoutines(routines.map(routine => 
        routine.id === editFormData.id ? editFormData : routine
      ));
      setEditingId(null);
      setEditFormData(null);
    }
  };

  const handleDeleteRoutine = (id: number) => {
    setRoutines(routines.filter(routine => routine.id !== id));
  };

  const toggleComplete = (id: number) => {
    setRoutines(routines.map(routine => 
      routine.id === id ? { ...routine, completed: !routine.completed } : routine
    ));
  };

  return (
    <Layout>
      <div className="bg-blue-50 py-8 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Fitness Routines</h1>
              <p className="text-lg text-gray-600 mt-2">
                Create and manage your regular fitness activities
              </p>
            </div>
            {!isAdding && (
              <button
                onClick={handleAddClick}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                Add Routine
              </button>
            )}
          </div>

          {/* Add New Routine Form */}
          {isAdding && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-blue-500">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Create New Routine</h2>
                <button onClick={handleCancelAdd} className="text-gray-400 hover:text-gray-600">
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <form onSubmit={handleSubmitNew}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Routine Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      required
                      value={newRoutine.name}
                      onChange={handleNewRoutineChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="frequency" className="block text-sm font-medium text-gray-700">
                      Frequency *
                    </label>
                    <input
                      type="text"
                      name="frequency"
                      id="frequency"
                      required
                      value={newRoutine.frequency}
                      onChange={handleNewRoutineChange}
                      placeholder="e.g., Daily, MWF, Weekends"
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div className="sm:col-span-2">
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      name="description"
                      id="description"
                      rows={3}
                      value={newRoutine.description}
                      onChange={handleNewRoutineChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    ></textarea>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={handleCancelAdd}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Save Routine
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Routines List */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {routines.length === 0 ? (
                <li className="p-6 text-center text-gray-500">
                  No routines found. Create your first routine to get started!
                </li>
              ) : (
                routines.map(routine => (
                  <li key={routine.id} className={`p-6 ${routine.completed ? 'bg-green-50' : ''}`}>
                    {editingId === routine.id && editFormData ? (
                      // Edit form
                      <form onSubmit={handleUpdateRoutine}>
                        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                          <div>
                            <label htmlFor="edit-name" className="block text-sm font-medium text-gray-700">
                              Routine Name *
                            </label>
                            <input
                              type="text"
                              name="name"
                              id="edit-name"
                              required
                              value={editFormData.name}
                              onChange={handleEditFormChange}
                              className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="edit-frequency" className="block text-sm font-medium text-gray-700">
                              Frequency *
                            </label>
                            <input
                              type="text"
                              name="frequency"
                              id="edit-frequency"
                              required
                              value={editFormData.frequency}
                              onChange={handleEditFormChange}
                              className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                            />
                          </div>
                          
                          <div className="sm:col-span-2">
                            <label htmlFor="edit-description" className="block text-sm font-medium text-gray-700">
                              Description
                            </label>
                            <textarea
                              name="description"
                              id="edit-description"
                              rows={3}
                              value={editFormData.description}
                              onChange={handleEditFormChange}
                              className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                            ></textarea>
                          </div>
                        </div>
                        
                        <div className="mt-6 flex justify-end space-x-3">
                          <button
                            type="button"
                            onClick={handleCancelEdit}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                          >
                            Update
                          </button>
                        </div>
                      </form>
                    ) : (
                      // Display mode
                      <div>
                        <div className="flex justify-between">
                          <div className="flex-1">
                            <div className="flex items-center">
                              <h3 className="text-lg font-medium text-gray-900 mr-2">{routine.name}</h3>
                              {routine.completed && (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  Completed
                                </span>
                              )}
                            </div>
                            <p className="mt-1 text-sm text-gray-600">{routine.description}</p>
                            <div className="mt-3 flex items-center text-sm text-gray-500">
                              <Repeat className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                              <span>Frequency: {routine.frequency}</span>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => toggleComplete(routine.id)}
                              className={`p-1 rounded-full ${
                                routine.completed
                                  ? 'text-green-600 hover:text-green-700 bg-green-100 hover:bg-green-200'
                                  : 'text-gray-400 hover:text-gray-500 bg-gray-100 hover:bg-gray-200'
                              }`}
                              title={routine.completed ? "Mark as incomplete" : "Mark as complete"}
                            >
                              <Check className="h-5 w-5" />
                            </button>
                            <button
                              onClick={() => handleEditClick(routine)}
                              className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                              title="Edit routine"
                            >
                              <Edit3 className="h-5 w-5" />
                            </button>
                            <button
                              onClick={() => handleDeleteRoutine(routine.id)}
                              className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                              title="Delete routine"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </li>
                ))
              )}
            </ul>
          </div>

          {/* Tips Section */}
          <div className="mt-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-orange-500">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Tips for Creating Effective Routines</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  <span>Be specific about what exercises or activities each routine includes</span>
                </li>
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  <span>Set realistic frequencies that fit into your schedule</span>
                </li>
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  <span>Balance your routines across different muscle groups and activity types</span>
                </li>
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  <span>Include rest days in your overall planning to allow for recovery</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Routines;