import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Layout from '../components/Layout';
import { Dumbbell, Utensils, Clock, LineChart, CheckCircle, Calendar } from 'lucide-react';

const Welcome: React.FC = () => {
  const { user } = useAuth();
  const [fitnessGoal, setFitnessGoal] = useState('');
  const [quickGoals, setQuickGoals] = useState([
    { id: 1, text: 'Drink 2L of water', completed: false },
    { id: 2, text: 'Walk 10,000 steps', completed: false },
    { id: 3, text: 'Complete leg workout', completed: false },
    { id: 4, text: 'Prep meals for tomorrow', completed: false },
  ]);

  const toggleGoalCompletion = (id: number) => {
    setQuickGoals(quickGoals.map(goal => 
      goal.id === id ? { ...goal, completed: !goal.completed } : goal
    ));
  };

  return (
    <Layout>
      <div className="bg-blue-50 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900">
              Welcome, {user?.username}!
            </h1>
            <p className="text-lg text-gray-600 mt-2">
              Let's continue your fitness journey. Here's your dashboard overview.
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 border-t-4 border-blue-500">
              <div className="flex items-center">
                <div className="p-3 bg-blue-100 rounded-full">
                  <Dumbbell className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-500">Workout Streak</p>
                  <p className="text-xl font-semibold">7 days</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 border-t-4 border-green-500">
              <div className="flex items-center">
                <div className="p-3 bg-green-100 rounded-full">
                  <Utensils className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-500">Calorie Target</p>
                  <p className="text-xl font-semibold">1,800 / 2,000</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 border-t-4 border-orange-500">
              <div className="flex items-center">
                <div className="p-3 bg-orange-100 rounded-full">
                  <Clock className="h-6 w-6 text-orange-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-500">Active Minutes</p>
                  <p className="text-xl font-semibold">45 min today</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 border-t-4 border-purple-500">
              <div className="flex items-center">
                <div className="p-3 bg-purple-100 rounded-full">
                  <LineChart className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-500">Weight Trend</p>
                  <p className="text-xl font-semibold">↓ 0.5 kg</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Dashboard Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Daily Goals */}
            <div className="col-span-1 bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-blue-600" />
                Today's Goals
              </h2>
              
              <div className="space-y-3 mb-4">
                {quickGoals.map(goal => (
                  <div 
                    key={goal.id} 
                    className="flex items-center p-3 border rounded-md hover:bg-gray-50 transition-colors duration-150"
                  >
                    <input 
                      type="checkbox" 
                      id={`goal-${goal.id}`} 
                      checked={goal.completed}
                      onChange={() => toggleGoalCompletion(goal.id)}
                      className="h-4 w-4 text-blue-600 rounded focus:ring-blue-500 border-gray-300"
                    />
                    <label 
                      htmlFor={`goal-${goal.id}`} 
                      className={`ml-3 cursor-pointer ${goal.completed ? 'line-through text-gray-400' : 'text-gray-700'}`}
                    >
                      {goal.text}
                    </label>
                  </div>
                ))}
              </div>
              
              <div className="mt-6">
                <div className="flex items-center mb-2">
                  <label htmlFor="fitness-goal" className="block text-sm font-medium text-gray-700">Add a goal:</label>
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    id="fitness-goal"
                    value={fitnessGoal}
                    onChange={(e) => setFitnessGoal(e.target.value)}
                    className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    placeholder="Enter a new goal"
                  />
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    onClick={() => {
                      if (fitnessGoal.trim()) {
                        setQuickGoals([...quickGoals, { 
                          id: Date.now(), 
                          text: fitnessGoal, 
                          completed: false 
                        }]);
                        setFitnessGoal('');
                      }
                    }}
                  >
                    Add
                  </button>
                </div>
              </div>
            </div>

            {/* Upcoming Workouts */}
            <div className="col-span-1 bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                Upcoming Workouts
              </h2>
              
              <div className="space-y-4">
                <div className="border rounded-md p-4 hover:bg-blue-50 transition-colors duration-150">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-gray-900">Upper Body Strength</h3>
                      <p className="text-sm text-gray-500">Tomorrow, 7:00 AM</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      45 min
                    </span>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 hover:bg-blue-50 transition-colors duration-150">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-gray-900">HIIT Cardio</h3>
                      <p className="text-sm text-gray-500">Wednesday, 6:30 PM</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                      30 min
                    </span>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 hover:bg-blue-50 transition-colors duration-150">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-gray-900">Leg Day</h3>
                      <p className="text-sm text-gray-500">Friday, 8:00 AM</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      60 min
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <Link
                  to="/training"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  View All Workouts
                </Link>
              </div>
            </div>

            {/* Quick Links */}
            <div className="col-span-1 bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">Quick Access</h2>
              
              <div className="grid grid-cols-2 gap-4">
                <Link 
                  to="/routines"
                  className="flex flex-col items-center p-4 border rounded-md hover:bg-blue-50 hover:border-blue-200 transition-colors duration-150"
                >
                  <Dumbbell className="h-8 w-8 text-blue-600 mb-2" />
                  <span className="text-gray-900 font-medium">Routines</span>
                </Link>
                
                <Link 
                  to="/nutrition"
                  className="flex flex-col items-center p-4 border rounded-md hover:bg-green-50 hover:border-green-200 transition-colors duration-150"
                >
                  <Utensils className="h-8 w-8 text-green-600 mb-2" />
                  <span className="text-gray-900 font-medium">Nutrition</span>
                </Link>
                
                <Link 
                  to="/training"
                  className="flex flex-col items-center p-4 border rounded-md hover:bg-purple-50 hover:border-purple-200 transition-colors duration-150"
                >
                  <LineChart className="h-8 w-8 text-purple-600 mb-2" />
                  <span className="text-gray-900 font-medium">Training</span>
                </Link>
                
                <Link 
                  to="/timer"
                  className="flex flex-col items-center p-4 border rounded-md hover:bg-orange-50 hover:border-orange-200 transition-colors duration-150"
                >
                  <Clock className="h-8 w-8 text-orange-600 mb-2" />
                  <span className="text-gray-900 font-medium">Timer</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Welcome;