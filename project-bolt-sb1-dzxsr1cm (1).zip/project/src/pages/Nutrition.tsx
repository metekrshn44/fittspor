import React, { useState } from 'react';
import Layout from '../components/Layout';
import { Plus, Utensils, Calendar, Edit3, Trash2, X, Coffee, Sun, Moon } from 'lucide-react';

interface MealEntry {
  id: number;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  time: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
}

const initialMeals: MealEntry[] = [
  {
    id: 1,
    name: 'Oatmeal with Berries',
    calories: 320,
    protein: 10,
    carbs: 45,
    fat: 8,
    time: '08:00',
    mealType: 'breakfast'
  },
  {
    id: 2,
    name: 'Grilled Chicken Salad',
    calories: 420,
    protein: 35,
    carbs: 20,
    fat: 15,
    time: '13:00',
    mealType: 'lunch'
  },
  {
    id: 3,
    name: 'Protein Shake',
    calories: 180,
    protein: 25,
    carbs: 10,
    fat: 3,
    time: '16:30',
    mealType: 'snack'
  },
  {
    id: 4,
    name: 'Salmon with Vegetables',
    calories: 550,
    protein: 40,
    carbs: 25,
    fat: 22,
    time: '19:30',
    mealType: 'dinner'
  }
];

const Nutrition: React.FC = () => {
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [meals, setMeals] = useState<MealEntry[]>(initialMeals);
  const [isAddingMeal, setIsAddingMeal] = useState<boolean>(false);
  const [editingMealId, setEditingMealId] = useState<number | null>(null);
  
  const [newMeal, setNewMeal] = useState<Omit<MealEntry, 'id'>>({
    name: '',
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    time: '',
    mealType: 'breakfast'
  });

  const dailyTotals = meals.reduce(
    (acc, meal) => {
      acc.calories += meal.calories;
      acc.protein += meal.protein;
      acc.carbs += meal.carbs;
      acc.fat += meal.fat;
      return acc;
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const calorieGoal = 2000;
  const proteinGoal = 150;
  const carbsGoal = 200;
  const fatGoal = 65;

  const calculatePercentage = (value: number, goal: number) => {
    return Math.min(Math.round((value / goal) * 100), 100);
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDate(e.target.value);
    // In a real app, this would fetch meals for the selected date
  };

  const handleAddMealClick = () => {
    setIsAddingMeal(true);
    setNewMeal({
      name: '',
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      time: '',
      mealType: 'breakfast'
    });
  };

  const handleNewMealChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const numericFields = ['calories', 'protein', 'carbs', 'fat'];
    setNewMeal({
      ...newMeal,
      [name]: numericFields.includes(name) ? Number(value) : value
    });
  };

  const handleMealSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingMealId !== null) {
      // Update existing meal
      setMeals(meals.map(meal => 
        meal.id === editingMealId ? { ...newMeal, id: editingMealId } : meal
      ));
      setEditingMealId(null);
    } else {
      // Add new meal
      const newId = Math.max(0, ...meals.map(m => m.id)) + 1;
      setMeals([...meals, { ...newMeal, id: newId }]);
    }
    
    setIsAddingMeal(false);
  };

  const handleCancelAdd = () => {
    setIsAddingMeal(false);
    setEditingMealId(null);
  };

  const handleEditMeal = (meal: MealEntry) => {
    setNewMeal({
      name: meal.name,
      calories: meal.calories,
      protein: meal.protein,
      carbs: meal.carbs,
      fat: meal.fat,
      time: meal.time,
      mealType: meal.mealType
    });
    setEditingMealId(meal.id);
    setIsAddingMeal(true);
  };

  const handleDeleteMeal = (id: number) => {
    setMeals(meals.filter(meal => meal.id !== id));
  };

  // Helper function to group meals by type
  const getMealsByType = (type: 'breakfast' | 'lunch' | 'dinner' | 'snack') => {
    return meals.filter(meal => meal.mealType === type)
      .sort((a, b) => a.time.localeCompare(b.time));
  };

  const getMealTypeIcon = (type: string) => {
    switch (type) {
      case 'breakfast':
        return <Coffee className="h-5 w-5 text-orange-500" />;
      case 'lunch':
        return <Sun className="h-5 w-5 text-yellow-500" />;
      case 'dinner':
        return <Moon className="h-5 w-5 text-blue-600" />;
      case 'snack':
        return <Utensils className="h-5 w-5 text-green-500" />;
      default:
        return <Utensils className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <Layout>
      <div className="bg-blue-50 py-8 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Nutrition Tracker</h1>
              <p className="text-lg text-gray-600 mt-2">
                Track your meals and monitor your nutritional intake
              </p>
            </div>
            
            <div className="mt-4 md:mt-0 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="date"
                  value={date}
                  onChange={handleDateChange}
                  className="pl-10 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                />
              </div>
              
              <button
                onClick={handleAddMealClick}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                Add Meal
              </button>
            </div>
          </div>

          {/* Nutrition Summary */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Daily Nutrition Summary</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Calories */}
              <div className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium text-gray-500">Calories</h3>
                  <span className="text-sm font-medium text-gray-900">{dailyTotals.calories} / {calorieGoal}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-blue-600 h-2.5 rounded-full" 
                    style={{ width: `${calculatePercentage(dailyTotals.calories, calorieGoal)}%` }}
                  ></div>
                </div>
              </div>
              
              {/* Protein */}
              <div className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium text-gray-500">Protein</h3>
                  <span className="text-sm font-medium text-gray-900">{dailyTotals.protein}g / {proteinGoal}g</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-red-500 h-2.5 rounded-full" 
                    style={{ width: `${calculatePercentage(dailyTotals.protein, proteinGoal)}%` }}
                  ></div>
                </div>
              </div>
              
              {/* Carbs */}
              <div className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium text-gray-500">Carbs</h3>
                  <span className="text-sm font-medium text-gray-900">{dailyTotals.carbs}g / {carbsGoal}g</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-yellow-500 h-2.5 rounded-full" 
                    style={{ width: `${calculatePercentage(dailyTotals.carbs, carbsGoal)}%` }}
                  ></div>
                </div>
              </div>
              
              {/* Fat */}
              <div className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium text-gray-500">Fat</h3>
                  <span className="text-sm font-medium text-gray-900">{dailyTotals.fat}g / {fatGoal}g</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-green-500 h-2.5 rounded-full" 
                    style={{ width: `${calculatePercentage(dailyTotals.fat, fatGoal)}%` }}
                  ></div>
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-1/6 text-center">
                    <span className="font-medium text-gray-900">Macros</span>
                  </div>
                  <div className="ml-4 w-5/6">
                    <div className="flex h-5">
                      <div 
                        className="h-5 bg-red-500" 
                        style={{ width: `${Math.round((dailyTotals.protein * 4 / dailyTotals.calories) * 100)}%` }}
                      ></div>
                      <div 
                        className="h-5 bg-yellow-500" 
                        style={{ width: `${Math.round((dailyTotals.carbs * 4 / dailyTotals.calories) * 100)}%` }}
                      ></div>
                      <div 
                        className="h-5 bg-green-500" 
                        style={{ width: `${Math.round((dailyTotals.fat * 9 / dailyTotals.calories) * 100)}%` }}
                      ></div>
                    </div>
                    <div className="flex text-xs text-gray-600 mt-1">
                      <div className="flex items-center mr-4">
                        <div className="w-2 h-2 bg-red-500 mr-1"></div>
                        <span>Protein ({Math.round((dailyTotals.protein * 4 / dailyTotals.calories) * 100)}%)</span>
                      </div>
                      <div className="flex items-center mr-4">
                        <div className="w-2 h-2 bg-yellow-500 mr-1"></div>
                        <span>Carbs ({Math.round((dailyTotals.carbs * 4 / dailyTotals.calories) * 100)}%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 mr-1"></div>
                        <span>Fat ({Math.round((dailyTotals.fat * 9 / dailyTotals.calories) * 100)}%)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Add/Edit Meal Form */}
          {isAddingMeal && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-blue-500">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                  {editingMealId !== null ? 'Edit Meal' : 'Add New Meal'}
                </h2>
                <button onClick={handleCancelAdd} className="text-gray-400 hover:text-gray-600">
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <form onSubmit={handleMealSubmit}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Meal Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      required
                      value={newMeal.name}
                      onChange={handleNewMealChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="mealType" className="block text-sm font-medium text-gray-700">
                      Meal Type *
                    </label>
                    <select
                      id="mealType"
                      name="mealType"
                      required
                      value={newMeal.mealType}
                      onChange={handleNewMealChange}
                      className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    >
                      <option value="breakfast">Breakfast</option>
                      <option value="lunch">Lunch</option>
                      <option value="dinner">Dinner</option>
                      <option value="snack">Snack</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="time" className="block text-sm font-medium text-gray-700">
                      Time *
                    </label>
                    <input
                      type="time"
                      name="time"
                      id="time"
                      required
                      value={newMeal.time}
                      onChange={handleNewMealChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="calories" className="block text-sm font-medium text-gray-700">
                      Calories *
                    </label>
                    <input
                      type="number"
                      name="calories"
                      id="calories"
                      required
                      min="0"
                      value={newMeal.calories}
                      onChange={handleNewMealChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="protein" className="block text-sm font-medium text-gray-700">
                      Protein (g) *
                    </label>
                    <input
                      type="number"
                      name="protein"
                      id="protein"
                      required
                      min="0"
                      value={newMeal.protein}
                      onChange={handleNewMealChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="carbs" className="block text-sm font-medium text-gray-700">
                      Carbs (g) *
                    </label>
                    <input
                      type="number"
                      name="carbs"
                      id="carbs"
                      required
                      min="0"
                      value={newMeal.carbs}
                      onChange={handleNewMealChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="fat" className="block text-sm font-medium text-gray-700">
                      Fat (g) *
                    </label>
                    <input
                      type="number"
                      name="fat"
                      id="fat"
                      required
                      min="0"
                      value={newMeal.fat}
                      onChange={handleNewMealChange}
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={handleCancelAdd}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {editingMealId !== null ? 'Update Meal' : 'Add Meal'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Meals List */}
          <div className="space-y-6">
            {/* Breakfast */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-orange-100 px-6 py-4 flex items-center">
                <Coffee className="h-6 w-6 text-orange-600 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">Breakfast</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {getMealsByType('breakfast').length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    No breakfast entries yet
                  </div>
                ) : (
                  getMealsByType('breakfast').map(meal => (
                    <div key={meal.id} className="p-6">
                      <div className="flex justify-between">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">{meal.name}</h3>
                            <span className="ml-2 text-sm text-gray-500">{meal.time}</span>
                          </div>
                          <div className="mt-2 grid grid-cols-4 gap-2 text-sm">
                            <div>
                              <span className="font-medium text-gray-900">{meal.calories}</span>
                              <span className="text-gray-600"> kcal</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.protein}g</span>
                              <span className="text-gray-600"> protein</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.carbs}g</span>
                              <span className="text-gray-600"> carbs</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.fat}g</span>
                              <span className="text-gray-600"> fat</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditMeal(meal)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                            title="Edit meal"
                          >
                            <Edit3 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteMeal(meal.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                            title="Delete meal"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Lunch */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-yellow-100 px-6 py-4 flex items-center">
                <Sun className="h-6 w-6 text-yellow-600 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">Lunch</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {getMealsByType('lunch').length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    No lunch entries yet
                  </div>
                ) : (
                  getMealsByType('lunch').map(meal => (
                    <div key={meal.id} className="p-6">
                      <div className="flex justify-between">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">{meal.name}</h3>
                            <span className="ml-2 text-sm text-gray-500">{meal.time}</span>
                          </div>
                          <div className="mt-2 grid grid-cols-4 gap-2 text-sm">
                            <div>
                              <span className="font-medium text-gray-900">{meal.calories}</span>
                              <span className="text-gray-600"> kcal</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.protein}g</span>
                              <span className="text-gray-600"> protein</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.carbs}g</span>
                              <span className="text-gray-600"> carbs</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.fat}g</span>
                              <span className="text-gray-600"> fat</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditMeal(meal)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                            title="Edit meal"
                          >
                            <Edit3 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteMeal(meal.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                            title="Delete meal"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Dinner */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-blue-100 px-6 py-4 flex items-center">
                <Moon className="h-6 w-6 text-blue-600 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">Dinner</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {getMealsByType('dinner').length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    No dinner entries yet
                  </div>
                ) : (
                  getMealsByType('dinner').map(meal => (
                    <div key={meal.id} className="p-6">
                      <div className="flex justify-between">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">{meal.name}</h3>
                            <span className="ml-2 text-sm text-gray-500">{meal.time}</span>
                          </div>
                          <div className="mt-2 grid grid-cols-4 gap-2 text-sm">
                            <div>
                              <span className="font-medium text-gray-900">{meal.calories}</span>
                              <span className="text-gray-600"> kcal</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.protein}g</span>
                              <span className="text-gray-600"> protein</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.carbs}g</span>
                              <span className="text-gray-600"> carbs</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.fat}g</span>
                              <span className="text-gray-600"> fat</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditMeal(meal)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                            title="Edit meal"
                          >
                            <Edit3 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteMeal(meal.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                            title="Delete meal"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Snacks */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-100 px-6 py-4 flex items-center">
                <Utensils className="h-6 w-6 text-green-600 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">Snacks</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {getMealsByType('snack').length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    No snack entries yet
                  </div>
                ) : (
                  getMealsByType('snack').map(meal => (
                    <div key={meal.id} className="p-6">
                      <div className="flex justify-between">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">{meal.name}</h3>
                            <span className="ml-2 text-sm text-gray-500">{meal.time}</span>
                          </div>
                          <div className="mt-2 grid grid-cols-4 gap-2 text-sm">
                            <div>
                              <span className="font-medium text-gray-900">{meal.calories}</span>
                              <span className="text-gray-600"> kcal</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.protein}g</span>
                              <span className="text-gray-600"> protein</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.carbs}g</span>
                              <span className="text-gray-600"> carbs</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-900">{meal.fat}g</span>
                              <span className="text-gray-600"> fat</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditMeal(meal)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-700 bg-blue-100 hover:bg-blue-200"
                            title="Edit meal"
                          >
                            <Edit3 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteMeal(meal.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-700 bg-red-100 hover:bg-red-200"
                            title="Delete meal"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Nutrition;